RGB = imread('image.jpg');
